# 🌙 Doux Dodo

Un site pour aider les parents à calmer leur bébé : comprendre pourquoi il pleure, appliquer les bons gestes, lancer un bruit apaisant, souffler soi-même, et garder une trace des crises pour en parler au pédiatre.

Projet front-end réalisé en **HTML, CSS et JavaScript natif (ES modules)**, sans framework ni bibliothèque, pour montrer la maîtrise des bases du web.

**Démo en ligne :** `https://johnnyrayane237.github.io/doux-dodo/` *(à activer, voir plus bas)*

---

## Fonctionnalités

| Section | Ce qu'elle fait | Techniques utilisées |
|---|---|---|
| **Hero** | Ciel étoilé animé, constellations autour du curseur, étoiles filantes au clic, lune et mobile de berceau en parallaxe | Canvas 2D, `requestAnimationFrame`, variables CSS pilotées en JS, animations CSS |
| **Assistant pleurs** | 7 questions dans l'ordre logique (signes d'alerte → faim → couche → température → ventre → fatigue → surstimulation) puis des conseils adaptés | Arbre de décision piloté par les données, rendu dynamique du DOM, délégation d'événements |
| **Les 5 S** | Cartes qui se retournent en 3D avec les gestes du Dr Harvey Karp | `transform-style: preserve-3d`, `backface-visibility`, `aria-pressed` |
| **Studio sonore** | Bruit blanc, rose, brun, battements de cœur, « chut » en vagues, berceuse en boîte à musique. Minuteur avec fondu de fin | **Web Audio API** : génération de bruit, filtres, oscillateurs, LFO, planificateur de notes, `AnalyserNode` |
| **Visualiseur** | Spectre circulaire qui réagit au son en temps réel | Canvas + analyse de fréquences |
| **Et vous ?** | Bulle de respiration guidée (4-2-6) et consignes de sécurité si le parent craque | Transitions CSS synchronisées avec des minuteurs JS |
| **Journal** | Chronomètre des crises, statistiques, histogramme par heure | `localStorage`, manipulation de dates, calculs |
| **Veilleuse** | Lumière douce plein écran, couleur au toucher, écran maintenu allumé | Screen Wake Lock API |
| **Signaux d'alerte** | Quand consulter, numéros d'urgence, bouton copier | Clipboard API avec solution de repli |

## Accessibilité et qualité

- HTML sémantique (`section`, `nav`, `fieldset`, `aria-live`, `aria-pressed`, rôles de dialogue)
- Navigation clavier complète avec focus visible
- Respect de `prefers-reduced-motion` : les animations sont coupées pour les personnes sensibles
- Police **Atkinson Hyperlegible**, conçue pour la lisibilité, adaptée à des parents fatigués
- Responsive du mobile au grand écran, sans défilement horizontal
- Aucune donnée envoyée : le journal reste dans le navigateur

## Structure du projet

```
doux-dodo/
├── index.html          structure de la page
├── css/
│   └── style.css       design, animations, responsive
└── js/
    ├── main.js         point d'entrée, relie les modules
    ├── sky.js          ciel étoilé (canvas)
    ├── sound.js        moteur audio + visualiseur
    ├── cry-guide.js    assistant de décodage des pleurs
    ├── breathing.js    respiration guidée
    └── journal.js      journal des pleurs (localStorage)
```

## Lancer le projet

Les modules JavaScript ne fonctionnent pas en ouvrant directement le fichier (`file://`). Il faut un petit serveur local :

- **VS Code** : extension *Live Server*, clic droit sur `index.html` → *Open with Live Server*
- ou en terminal : `python -m http.server 8000` puis ouvrir `http://localhost:8000`

## Mettre en ligne avec GitHub Pages

1. Pousser le dossier sur un dépôt `doux-dodo`
2. *Settings* → *Pages* → *Branch : main* → *Save*
3. Le site est disponible à l'adresse indiquée après une minute

## Pistes d'amélioration

- Version React avec composants réutilisables
- Mode hors ligne (PWA) pour utiliser la veilleuse et les sons sans réseau
- Export du journal en PDF pour le pédiatre
- Traduction en anglais

## Sources des contenus

Méthode des 5 S du Dr Harvey Karp, recommandations de couchage sur le dos, prévention du syndrome du bébé secoué, ligne Allô Parents Bébé de l'association Enfance et Partage.

> Ce site donne des repères généraux et ne remplace pas l'avis d'un professionnel de santé.

---

## Me contacter

Conçu et développé par **Johanne Rayane Nkeuchatchou**, étudiant en Bachelor Administration Systèmes, Réseaux et Cybersécurité, à la recherche d'une alternance ou d'un CDI en développement web front-end.

- 📧 E-mail : [johannepamegne@gmail.com](mailto:johannepamegne@gmail.com)
- 📱 Téléphone : +33 7 43 16 37 92
- 💻 GitHub : [github.com/Johnnyrayane237](https://github.com/Johnnyrayane237)
