// Journal des pleurs : chronomètre, statistiques et histogramme par heure.
// Les données sont enregistrées dans le localStorage du navigateur (rien n'est envoyé).
const STORE_KEY = 'douxdodo-journal-v1';

function loadEntries() {
  try { return JSON.parse(localStorage.getItem(STORE_KEY)) || []; } catch { return []; }
}
function saveEntries(list) {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(list)); } catch { /* stockage indisponible : on continue en mémoire */ }
}

// Données d'exemple, recalculées par rapport à aujourd'hui, pour que le journal
// montre tout de suite à quoi il sert. Elles disparaissent à la première vraie entrée.
function sampleEntries() {
  const day = 86400000;
  const at = (daysAgo, h, m, mins, help) => {
    const d = new Date(); d.setHours(h, m, 0, 0);
    const start = d.getTime() - daysAgo * day;
    return { start, end: start + mins * 60000, help, sample: true };
  };
  return [
    at(0, 18, 40, 24, 'Bercement'), at(0, 6, 10, 9, 'Tétée / biberon'),
    at(1, 19, 5, 41, 'Bruit blanc'), at(1, 22, 30, 18, 'Peau à peau'), at(1, 3, 15, 12, 'Tétée / biberon'),
    at(2, 18, 20, 35, 'Bruit blanc'), at(2, 20, 0, 22, 'Rot'), at(3, 19, 30, 48, 'Rien n\'a marché'),
  ];
}

export function initJournal(root, { toast }) {
  if (!root) return;
  const $ = s => root.querySelector(s);
  const live = $('.journal-live'), sw = $('#stopwatch'), toggle = $('#cry-toggle'), cause = $('#cry-cause');
  const log = $('#log'), hours = $('#hours'), note = $('#sample-note');
  let entries = loadEntries();
  if (!entries.length) entries = sampleEntries();
  let startedAt = null, tickId = null;

  const mins = e => Math.max(1, Math.round((e.end - e.start) / 60000));
  const fmtTime = t => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  const fmtDay = t => {
    const d = new Date(t), today = new Date();
    const diff = Math.round((new Date(today.toDateString()) - new Date(d.toDateString())) / 86400000);
    return diff === 0 ? 'Aujourd\'hui' : diff === 1 ? 'Hier' : d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric' });
  };

  function render() {
    const isSample = entries.some(e => e.sample);
    note.hidden = !isSample;
    const sorted = [...entries].sort((a, b) => b.start - a.start);

    // indicateurs
    const todayStr = new Date().toDateString();
    const today = entries.filter(e => new Date(e.start).toDateString() === todayStr).reduce((s, e) => s + mins(e), 0);
    const avg = entries.length ? Math.round(entries.reduce((s, e) => s + mins(e), 0) / entries.length) : 0;
    const perHour = Array(24).fill(0);
    entries.forEach(e => { perHour[new Date(e.start).getHours()] += mins(e); });
    const max = Math.max(...perHour);
    const peak = max ? perHour.indexOf(max) : -1;
    $('#k-today').textContent = `${today} min`;
    $('#k-avg').textContent = `${avg} min`;
    $('#k-peak').textContent = peak < 0 ? '–' : `${peak} h – ${peak + 1} h`;

    // histogramme par heure de début
    hours.innerHTML = perHour.map((v, i) =>
      `<span class="${v ? '' : 'zero'}" style="--h:${max ? Math.max(2, (v / max) * 100) : 2}%;--i:${i}" title="${i} h : ${v} min"></span>`
    ).join('');

    // liste
    log.innerHTML = sorted.slice(0, 20).map(e => `
      <li><span>${fmtDay(e.start)} à ${fmtTime(e.start)}<small>${e.help}</small></span>
      <span class="mono">${mins(e)} min</span></li>`).join('') || '<li><span>Aucune entrée pour l\'instant.</span></li>';
  }

  function tick() {
    const s = Math.floor((Date.now() - startedAt) / 1000);
    sw.textContent = `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  }

  toggle.addEventListener('click', () => {
    if (!startedAt) {
      startedAt = Date.now();
      live.classList.add('live');
      toggle.textContent = 'Il s\'est calmé, arrêter';
      tick(); tickId = setInterval(tick, 1000);
    } else {
      clearInterval(tickId);
      if (entries.some(e => e.sample)) entries = []; // on retire les exemples
      entries.push({ start: startedAt, end: Date.now(), help: cause.value });
      saveEntries(entries);
      startedAt = null;
      live.classList.remove('live');
      toggle.textContent = 'Il pleure, démarrer';
      sw.textContent = '00:00';
      render();
      toast('Crise enregistrée dans le journal');
    }
  });

  // effacement en deux temps (les boîtes confirm() ne sont pas fiables partout)
  const clearBtn = $('#clear-log');
  let armed = false, armTimer;
  clearBtn.addEventListener('click', () => {
    if (!armed) {
      armed = true; clearBtn.textContent = 'Toucher encore pour confirmer';
      armTimer = setTimeout(() => { armed = false; clearBtn.textContent = 'Effacer le journal'; }, 3000);
      return;
    }
    clearTimeout(armTimer); armed = false; clearBtn.textContent = 'Effacer le journal';
    entries = []; saveEntries(entries); render();
    toast('Journal effacé');
  });

  render();
}
