// Point d'entrée : relie chaque module à la page.
import { initSky } from './sky.js';
import { createSoundEngine } from './sound.js';
import { initCryGuide } from './cry-guide.js';
import { initBreathing } from './breathing.js';
import { initJournal } from './journal.js';

const qs = (s, el = document) => el.querySelector(s);
const qsa = (s, el = document) => [...el.querySelectorAll(s)];

// ---------- Notification courte ----------
const toastEl = qs('#toast');
let toastTimer;
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2600);
}

// ---------- Titre animé lettre par lettre ----------
function splitTitle() {
  let i = 0; // compteur partagé : la 2e ligne enchaîne après la 1re
  qsa('.split').forEach(el => {
    const text = el.dataset.text;
    el.setAttribute('aria-label', text);
    el.innerHTML = [...text].map(ch => {
      const html = ch === ' ' ? '<span class="ch sp" aria-hidden="true"> </span>'
        : `<span class="ch" aria-hidden="true" style="--i:${i}">${ch}</span>`;
      i++;
      return html;
    }).join('');
  });
}

// ---------- Apparition au défilement ----------
// Seuls les blocs encore sous l'écran au chargement sont décalés,
// ce qui est déjà visible reste net immédiatement.
function initReveal() {
  const items = qsa('.reveal');
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.remove('pre');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  items.forEach((el, i) => {
    if (el.getBoundingClientRect().top > innerHeight) {
      el.classList.add('pre');
      el.style.transitionDelay = `${(i % 5) * 70}ms`;
      io.observe(el);
    }
  });
}

// ---------- Lien actif dans le menu ----------
function initNav() {
  const links = qsa('.nav a');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === `#${e.target.id}`));
      }
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  qsa('section[id]').forEach(s => io.observe(s));
}

// ---------- Halo qui suit la souris ----------
function initCursor() {
  const glow = qs('.cursor-glow');
  if (!glow || !matchMedia('(hover: hover)').matches) return;
  let x = -500, y = -500, cx = x, cy = y;
  addEventListener('pointermove', e => { x = e.clientX; y = e.clientY; });
  (function loop() {
    cx += (x - cx) * 0.12; cy += (y - cy) * 0.12;
    glow.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
    requestAnimationFrame(loop);
  })();
}

// ---------- Cartes 5 S ----------
function initCards() {
  qsa('.flip').forEach(card => card.addEventListener('click', () => {
    card.setAttribute('aria-pressed', card.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
  }));
}

// ---------- Studio sonore ----------
function initStudio() {
  const playBtn = qs('#play-toggle');
  const countdown = qs('#countdown');
  const volume = qs('#volume');
  const names = { white: 'Bruit blanc', pink: 'Bruit rose', brown: 'Bruit brun', heart: 'Battements de cœur', shush: 'Chuuut', lullaby: 'Boîte à musique' };
  const fmt = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const engine = createSoundEngine({
    canvas: qs('#viz'),
    onChange: ({ playing, remaining }) => {
      playBtn.setAttribute('aria-pressed', String(playing));
      if (remaining !== undefined) countdown.textContent = fmt(remaining);
    },
  });

  const selected = () => qs('input[name="sound"]:checked').value;
  function playType(type) {
    const radio = qs(`input[name="sound"][value="${type}"]`);
    if (radio) radio.checked = true;
    engine.play(type);
    toast(`${names[type]} en cours`);
  }

  playBtn.addEventListener('click', () => (engine.playing ? engine.stop() : playType(selected())));
  qsa('input[name="sound"]').forEach(r => r.addEventListener('change', () => { if (engine.playing) playType(r.value); }));
  volume.addEventListener('input', () => {
    volume.style.setProperty('--fill', `${volume.value}%`);
    engine.setVolume((volume.value / 100) ** 1.6); // courbe perçue plus naturelle
  });
  engine.setVolume((volume.value / 100) ** 1.6);
  qsa('[data-timer]').forEach(b => b.addEventListener('click', () => {
    qsa('[data-timer]').forEach(x => x.classList.toggle('on', x === b));
    engine.setTimer(Number(b.dataset.timer));
  }));
  // boutons « lancer un son » ailleurs dans la page
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-play-sound]');
    if (b) playType(b.dataset.playSound);
  });
  return playType;
}

// ---------- Veilleuse plein écran ----------
function initNightlight() {
  const nl = qs('#nightlight');
  const colors = ['255, 180, 120', '183, 166, 255', '255, 157, 180', '140, 210, 255', '255, 226, 168'];
  let c = 0, wakeLock = null;
  const stars = qs('#nl-stars');
  stars.innerHTML = Array.from({ length: 60 }, () =>
    `<i style="left:${Math.random() * 100}%;top:${Math.random() * 100}%;animation-delay:${-Math.random() * 3}s;opacity:${0.3 + Math.random() * 0.7}"></i>`
  ).join('');

  async function open() {
    nl.hidden = false;
    document.body.style.overflow = 'hidden';
    qs('#close-nightlight').focus();
    try { wakeLock = await navigator.wakeLock?.request('screen'); } catch { /* pas grave */ }
  }
  function close() {
    nl.hidden = true;
    document.body.style.overflow = '';
    wakeLock?.release?.(); wakeLock = null;
    qs('#open-nightlight').focus();
  }
  qs('#open-nightlight').addEventListener('click', open);
  qs('#close-nightlight').addEventListener('click', e => { e.stopPropagation(); close(); });
  nl.addEventListener('click', () => { c = (c + 1) % colors.length; nl.style.setProperty('--nl', colors[c]); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && !nl.hidden) close(); });
}

// ---------- Copier un numéro ----------
function initCopy() {
  qsa('[data-copy]').forEach(b => b.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(b.dataset.copy); toast(b.dataset.label || 'Numéro copié'); }
    catch {
      const sel = getSelection(), range = document.createRange();
      range.selectNodeContents(b.closest('.num, .contact-item').querySelector('.big'));
      sel.removeAllRanges(); sel.addRange(range);
      toast('Texte sélectionné, copiez-le');
    }
  }));
}

// ---------- Démarrage ----------
splitTitle();
initSky(qs('#sky'));
initReveal();
initNav();
initCursor();
initCards();
const playType = initStudio();
initCryGuide(qs('#cry-guide'), { onSound: playType });
initBreathing(qs('#breath'));
initJournal(qs('#journal'), { toast });
initNightlight();
initCopy();
