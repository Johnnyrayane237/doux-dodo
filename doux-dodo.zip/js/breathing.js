// Respiration guidée pour le parent : 4 s d'inspiration, 2 s de pause, 6 s d'expiration.
// Une expiration plus longue que l'inspiration aide à ralentir le rythme cardiaque.
const PHASES = [
  { word: 'Inspirez', secs: 4, scale: 1.9 },
  { word: 'Retenez', secs: 2, scale: 1.9 },
  { word: 'Soufflez', secs: 6, scale: 1 },
];
const CYCLES = 5; // 5 × 12 s = 1 minute

export function initBreathing(root) {
  if (!root) return;
  const orb = root.querySelector('#orb');
  const word = root.querySelector('#breath-word');
  const count = root.querySelector('#breath-count');
  const btn = root.querySelector('#breath-start');
  const info = root.querySelector('#breath-cycles');
  let timers = [], running = false;

  function clearAll() { timers.forEach(clearTimeout); timers = []; }

  function stop(done) {
    clearAll(); running = false;
    orb.classList.remove('running');
    orb.style.transitionDuration = '1.5s';
    orb.style.transform = 'scale(1)';
    word.textContent = done ? 'Bravo' : 'Prêt ?';
    count.textContent = done ? 'Vous pouvez y retourner' : '';
    btn.textContent = done ? 'Encore une minute' : 'Commencer 1 minute';
    info.textContent = 'Inspirer 4 s · Retenir 2 s · Souffler 6 s';
  }

  function start() {
    running = true;
    orb.classList.add('running');
    btn.textContent = 'Arrêter';
    let t = 0;
    for (let c = 0; c < CYCLES; c++) {
      for (const p of PHASES) {
        timers.push(setTimeout(() => {
          word.textContent = p.word;
          orb.style.transitionDuration = `${p.secs}s`;
          orb.style.transform = `scale(${p.scale})`;
          info.textContent = `Cycle ${c + 1} sur ${CYCLES}`;
        }, t * 1000));
        for (let s = 0; s < p.secs; s++) {
          timers.push(setTimeout(() => { count.textContent = String(p.secs - s); }, (t + s) * 1000));
        }
        t += p.secs;
      }
    }
    timers.push(setTimeout(() => stop(true), t * 1000));
  }

  btn.addEventListener('click', () => (running ? stop(false) : start()));
}
