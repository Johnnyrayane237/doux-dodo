// Assistant « Pourquoi pleure-t-il ? »
// Un arbre de décision simple, décrit par des données : on vérifie d'abord
// les signes d'alerte, puis les besoins de base, dans l'ordre le plus probable.
const STEPS = [
  {
    id: 'alerte', tag: 'Alerte',
    q: 'Voyez-vous un de ces signes ?',
    help: 'Fièvre de 38 °C ou plus avant 3 mois, respiration difficile, teint gris ou bleuté, bébé très mou, ou pleurs aigus qui ne lui ressemblent pas.',
    yes: 'Oui, au moins un', no: 'Non, aucun',
    result: {
      warn: true,
      title: 'Appelez sans attendre',
      why: 'Ces signes demandent un avis médical rapide. Vous ne dérangez personne.',
      tips: ['Composez le 15 (SAMU) ou le 112.', 'Gardez bébé près de vous, sur le dos s\'il dort.', 'Notez l\'heure du début des symptômes et sa température.'],
      actions: [{ label: 'Voir les numéros utiles', href: '#consulter', primary: true }],
    },
  },
  {
    id: 'faim', tag: 'Faim',
    q: 'Pourrait-il avoir faim ?',
    help: 'Il tourne la tête en ouvrant la bouche, suce ses mains, ou la dernière tétée remonte à plus de 2 à 3 heures.',
    yes: 'Oui, c\'est possible', no: 'Non, il a mangé',
    result: {
      title: 'Proposez-lui à manger',
      why: 'Les pleurs sont un signe de faim tardif. Les petits signes (mains à la bouche, recherche du sein) apparaissent avant.',
      tips: ['Proposez le sein ou le biberon, au calme.', 'Faites une pause au milieu pour un rot.', 'S\'il refuse de boire plusieurs fois de suite, parlez-en au médecin.'],
    },
  },
  {
    id: 'couche', tag: 'Couche',
    q: 'Sa couche est-elle mouillée ou sale ?',
    help: 'Une couche pleine ou une irritation sur les fesses peuvent suffire à le gêner.',
    yes: 'Oui', no: 'Non, elle est propre',
    result: {
      title: 'Un change et une crème',
      why: 'L\'humidité et les rougeurs irritent la peau fragile d\'un nourrisson.',
      tips: ['Changez-le sur une surface chaude, en lui parlant doucement.', 'Séchez bien les plis avant de remettre la couche.', 'Une crème au zinc protège en cas de rougeurs.'],
    },
  },
  {
    id: 'temperature', tag: 'Chaud / froid',
    q: 'Sa nuque est-elle moite, ou ses bras froids ?',
    help: 'Touchez sa nuque, pas ses mains : les mains d\'un bébé sont souvent fraîches, c\'est normal.',
    yes: 'Oui', no: 'Non, ça va',
    result: {
      title: 'Ajustez la température',
      why: 'Un bébé ne régule pas encore bien sa température, et il a facilement trop chaud.',
      tips: ['Une chambre entre 18 et 20 °C convient bien.', 'Habillez-le avec une couche de plus que vous, pas davantage.', 'Pas de bonnet ni de couverture dans le lit pour dormir.'],
    },
  },
  {
    id: 'gaz', tag: 'Ventre',
    q: 'Il se tortille et replie les jambes ?',
    help: 'Ventre tendu, visage rouge, jambes ramenées sur le ventre, souvent après une tétée.',
    yes: 'Oui, c\'est ça', no: 'Non',
    result: {
      title: 'Aidez-le à évacuer l\'air',
      why: 'L\'air avalé pendant la tétée et l\'immaturité digestive provoquent souvent des inconforts.',
      tips: ['Tenez-le à la verticale contre votre épaule et tapotez son dos.', 'Massez son ventre dans le sens des aiguilles d\'une montre.', 'Faites-lui faire des mouvements de pédalage avec les jambes.'],
      actions: [{ label: 'Lancer des battements de cœur', sound: 'heart', primary: true }],
    },
  },
  {
    id: 'fatigue', tag: 'Fatigue',
    q: 'Il bâille, frotte ses yeux, ou est réveillé depuis longtemps ?',
    help: 'Avant 3 mois, un bébé ne reste souvent éveillé qu\'une heure à une heure et demie d\'affilée.',
    yes: 'Oui', no: 'Non',
    result: {
      title: 'Il a besoin de dormir',
      why: 'Un bébé trop fatigué pleure plus et a plus de mal à s\'endormir, d\'où l\'intérêt de repérer les premiers signes.',
      tips: ['Baissez la lumière et le bruit autour de lui.', 'Utilisez les 5 S : emmailloter, chut, bercer, téter.', 'Couchez-le sur le dos, dans un lit vide, quand il somnole.'],
      actions: [{ label: 'Lancer le bruit rose', sound: 'pink', primary: true }, { label: 'Voir les 5 S', href: '#methodes' }],
    },
  },
  {
    id: 'stimulation', tag: 'Trop d\'éveil',
    q: 'Beaucoup de monde, de bruit ou d\'écrans aujourd\'hui ?',
    help: 'Visites, magasins, télévision allumée : en fin de journée, tout ressort.',
    yes: 'Oui, journée chargée', no: 'Non, plutôt calme',
    result: {
      title: 'Il a besoin de calme',
      why: 'Trop de stimulations surchargent son système nerveux encore immature. Les pleurs l\'aident à décharger.',
      tips: ['Isolez-vous dans une pièce sombre et silencieuse.', 'Peau à peau ou portage : votre odeur et votre cœur le rassurent.', 'Parlez peu, bougez lentement.'],
      actions: [{ label: 'Lancer le bruit brun', sound: 'brown', primary: true }],
    },
  },
];

const FALLBACK = {
  title: 'Peut-être des pleurs du soir',
  why: 'Entre 2 semaines et 4 mois, beaucoup de bébés pleurent sans raison apparente, surtout en fin de journée. C\'est épuisant, mais en général pas grave, et ça passe.',
  tips: ['Essayez les 5 S, l\'un après l\'autre, quelques minutes chacun.', 'Un bruit blanc continu aide souvent beaucoup.', 'Si vous saturez : bébé au lit sur le dos, et pause de quelques minutes pour vous.', 'Pleurs inhabituels ou qui durent des heures : demandez l\'avis du médecin.'],
  actions: [{ label: 'Lancer le bruit blanc', sound: 'white', primary: true }, { label: 'Respirer une minute', href: '#vous' }],
};

export function initCryGuide(root, { onSound }) {
  if (!root) return;
  const card = root.querySelector('#guide-card');
  const bar = root.querySelector('#guide-bar');
  const dots = root.querySelector('#guide-dots');
  let index = 0;

  dots.innerHTML = STEPS.map(s => `<span role="listitem">${s.tag}</span>`).join('');
  const dotEls = [...dots.children];

  function animate() {
    card.classList.remove('enter');
    void card.offsetWidth; // relance l'animation CSS
    card.classList.add('enter');
  }

  function renderQuestion() {
    const s = STEPS[index];
    bar.style.width = `${(index / STEPS.length) * 100}%`;
    dotEls.forEach((d, i) => { d.className = i < index ? 'done' : i === index ? 'now' : ''; });
    card.innerHTML = `
      <p class="eyebrow">Question ${index + 1} sur ${STEPS.length}</p>
      <p class="q-title">${s.q}</p>
      <p class="q-help">${s.help}</p>
      <div class="answers">
        <button class="answer yes" type="button" data-a="yes">${s.yes}</button>
        <button class="answer" type="button" data-a="no">${s.no}</button>
      </div>`;
    animate();
  }

  function renderResult(r, flaggedIndex) {
    bar.style.width = '100%';
    dotEls.forEach((d, i) => { d.className = i === flaggedIndex ? 'flag' : i < (flaggedIndex ?? STEPS.length) ? 'done' : ''; });
    const actions = (r.actions || []).map(a => a.href
      ? `<a class="btn ${a.primary ? 'btn-primary' : 'btn-ghost'}" href="${a.href}">${a.label}</a>`
      : `<button class="btn ${a.primary ? 'btn-primary' : 'btn-ghost'}" type="button" data-sound="${a.sound}">${a.label}</button>`).join('');
    card.innerHTML = `
      <div class="result ${r.warn ? 'warn' : ''}">
        <p class="eyebrow">${r.warn ? 'Priorité' : 'Piste probable'}</p>
        <h3>${r.title}</h3>
        <p class="why">${r.why}</p>
        <ul class="tip-list">${r.tips.map(t => `<li>${t}</li>`).join('')}</ul>
        <div class="result-actions">${actions}
          <button class="btn btn-ghost" type="button" data-restart>Recommencer</button>
        </div>
      </div>`;
    animate();
  }

  card.addEventListener('click', e => {
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.restart !== undefined) { index = 0; renderQuestion(); return; }
    if (btn.dataset.sound) { onSound(btn.dataset.sound); return; }
    if (btn.dataset.a === 'yes') renderResult(STEPS[index].result, index);
    else if (btn.dataset.a === 'no') {
      index++;
      if (index < STEPS.length) renderQuestion();
      else renderResult(FALLBACK, null);
    }
  });

  renderQuestion();
}
