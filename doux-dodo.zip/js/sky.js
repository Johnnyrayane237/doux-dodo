// Ciel étoilé du hero : étoiles qui scintillent, parallaxe à la souris,
// étoiles filantes, et constellations qui se dessinent autour du curseur.
export function initSky(canvas) {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let w = 0, h = 0, stars = [], shooters = [];
  const mouse = { x: -9999, y: -9999, tx: 0, ty: 0, px: 0, py: 0 };

  function resize() {
    const r = canvas.getBoundingClientRect();
    w = r.width; h = r.height;
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.round((w * h) / 2600);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      z: Math.random() * 0.9 + 0.1,          // profondeur, pour la parallaxe
      r: Math.random() * 1.4 + 0.3,
      tw: Math.random() * Math.PI * 2,       // phase de scintillement
      sp: Math.random() * 0.02 + 0.005,
      warm: Math.random() < 0.18,
    }));
  }

  function spawnShooter(x, y) {
    const angle = Math.PI / 5 + Math.random() * 0.3;
    shooters.push({
      x: x ?? Math.random() * w * 0.7,
      y: y ?? Math.random() * h * 0.4,
      vx: Math.cos(angle) * 9, vy: Math.sin(angle) * 9,
      life: 1,
    });
  }

  function frame() {
    ctx.clearRect(0, 0, w, h);
    // la parallaxe suit la souris avec un léger retard (lissage)
    mouse.px += (mouse.tx - mouse.px) * 0.05;
    mouse.py += (mouse.ty - mouse.py) * 0.05;

    const near = [];
    for (const s of stars) {
      s.tw += s.sp;
      const x = s.x + mouse.px * s.z * 30;
      const y = s.y + mouse.py * s.z * 30;
      const a = 0.35 + Math.sin(s.tw) * 0.35 + s.z * 0.3;
      ctx.beginPath();
      ctx.arc(x, y, s.r * (0.6 + s.z * 0.6), 0, Math.PI * 2);
      ctx.fillStyle = s.warm ? `rgba(255,226,168,${a})` : `rgba(238,240,255,${a})`;
      ctx.fill();
      const d = Math.hypot(x - mouse.x, y - mouse.y);
      if (d < 140) near.push({ x, y, d });
    }

    // constellations : relie les étoiles proches du curseur
    near.sort((a, b) => a.d - b.d);
    const pts = near.slice(0, 7);
    for (let i = 0; i < pts.length; i++) {
      for (let j = i + 1; j < pts.length; j++) {
        const dd = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
        if (dd < 90) {
          ctx.strokeStyle = `rgba(183,166,255,${0.5 * (1 - dd / 90)})`;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke();
        }
      }
    }

    // étoiles filantes
    if (Math.random() < 0.004) spawnShooter();
    shooters = shooters.filter(s => s.life > 0);
    for (const s of shooters) {
      s.x += s.vx; s.y += s.vy; s.life -= 0.012;
      const g = ctx.createLinearGradient(s.x, s.y, s.x - s.vx * 12, s.y - s.vy * 12);
      g.addColorStop(0, `rgba(255,240,210,${s.life})`);
      g.addColorStop(1, 'rgba(255,240,210,0)');
      ctx.strokeStyle = g; ctx.lineWidth = 2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - s.vx * 12, s.y - s.vy * 12); ctx.stroke();
    }
    if (!reduce) requestAnimationFrame(frame);
  }

  window.addEventListener('resize', resize);
  canvas.parentElement.addEventListener('pointermove', e => {
    const r = canvas.getBoundingClientRect();
    mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top;
    mouse.tx = (e.clientX / innerWidth - 0.5) * 2;
    mouse.ty = (e.clientY / innerHeight - 0.5) * 2;
    // la lune et le mobile suivent aussi (variables CSS)
    document.documentElement.style.setProperty('--px', `${mouse.tx * 14}px`);
    document.documentElement.style.setProperty('--py', `${mouse.ty * 10}px`);
  });
  canvas.parentElement.addEventListener('pointerleave', () => { mouse.x = mouse.y = -9999; });
  // un clic dans le ciel fait un vœu : une étoile filante part du curseur
  canvas.parentElement.addEventListener('click', e => {
    if (e.target.closest('a, button')) return;
    const r = canvas.getBoundingClientRect();
    spawnShooter(e.clientX - r.left, e.clientY - r.top);
  });

  resize();
  requestAnimationFrame(frame); // en mode « moins d'animations », une seule image fixe
}
