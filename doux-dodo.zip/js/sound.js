// Studio sonore : tous les sons sont synthétisés avec la Web Audio API,
// sans aucun fichier audio. Un AnalyserNode alimente la visualisation circulaire.
export function createSoundEngine({ canvas, onChange }) {
  let ctx = null, master = null, analyser = null;
  let current = null;          // { type, stop() }
  let volume = 0.45;
  let timerMinutes = 30, endsAt = 0, timerId = null;

  // ---------- Initialisation (au premier clic : obligatoire pour l'audio) ----------
  function ensureContext() {
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = 0;
    analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.82;
    master.connect(analyser);
    analyser.connect(ctx.destination);
  }

  // ---------- Générateurs de bruit ----------
  function noiseBuffer(kind) {
    const len = ctx.sampleRate * 4;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0, last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      if (kind === 'white') d[i] = white * 0.35;
      else if (kind === 'pink') { // filtre de Paul Kellet
        b0 = 0.99886 * b0 + white * 0.0555179; b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520; b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522; b5 = -0.7616 * b5 - white * 0.0168980;
        d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.09;
        b6 = white * 0.115926;
      } else { // brun : intégration du bruit blanc
        last = (last + 0.02 * white) / 1.02;
        d[i] = last * 3.2;
      }
    }
    return buf;
  }

  function loopNoise(kind, out) {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuffer(kind);
    src.loop = true;
    src.connect(out);
    src.start();
    return src;
  }

  // Planificateur « look-ahead » : programme les notes un peu en avance
  // pour un rythme précis, même si l'onglet ralentit.
  function scheduler(step) {
    let next = ctx.currentTime + 0.1;
    const id = setInterval(() => {
      while (next < ctx.currentTime + 0.25) next = step(next);
    }, 25);
    return () => clearInterval(id);
  }

  // ---------- Les sons ----------
  const makers = {
    white: out => { const s = loopNoise('white', out); return () => s.stop(); },
    pink:  out => { const s = loopNoise('pink', out);  return () => s.stop(); },
    brown: out => {
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
      lp.connect(out);
      const s = loopNoise('brown', lp);
      return () => s.stop();
    },

    heart: out => {
      // « poum-poum » : deux impulsions graves par seconde (60 bpm)
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 160; lp.connect(out);
      const thump = (t, f, g) => {
        const o = ctx.createOscillator(), e = ctx.createGain();
        o.frequency.setValueAtTime(f, t);
        o.frequency.exponentialRampToValueAtTime(f * 0.5, t + 0.15);
        e.gain.setValueAtTime(0.0001, t);
        e.gain.exponentialRampToValueAtTime(g, t + 0.015);
        e.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
        o.connect(e).connect(lp); o.start(t); o.stop(t + 0.25);
      };
      // un fond de bruit brun très bas, comme dans le ventre
      const bed = ctx.createGain(); bed.gain.value = 0.25; bed.connect(out);
      const s = loopNoise('brown', bed);
      const stop = scheduler(t => { thump(t, 70, 1.4); thump(t + 0.28, 60, 0.9); return t + 1; });
      return () => { stop(); s.stop(); };
    },

    shush: out => {
      // bruit rose filtré autour de 3 kHz, volume modulé en vagues lentes
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 3200; bp.Q.value = 0.7;
      const wave = ctx.createGain(); wave.gain.value = 0.55;
      const lfo = ctx.createOscillator(), depth = ctx.createGain();
      lfo.frequency.value = 0.38; depth.gain.value = 0.45;
      lfo.connect(depth).connect(wave.gain);
      const boost = ctx.createGain(); boost.gain.value = 2.2; // le filtre enlève de l'énergie
      bp.connect(wave).connect(boost).connect(out);
      const s = loopNoise('pink', bp);
      lfo.start();
      return () => { s.stop(); lfo.stop(); };
    },

    lullaby: out => {
      // « Au clair de la lune » (domaine public) en timbre de boîte à musique
      const N = { G4: 392, A4: 440, B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25 };
      const A = [['C5',1],['C5',1],['C5',1],['D5',1],['E5',2],['D5',2],['C5',1],['E5',1],['D5',1],['D5',1],['C5',4]];
      const B = [['D5',1],['D5',1],['D5',1],['D5',1],['A4',2],['A4',2],['D5',1],['C5',1],['B4',1],['A4',1],['G4',4]];
      const song = [...A, ...A, ...B, ...A];
      const beat = 0.6;
      const verb = ctx.createDelay(); verb.delayTime.value = 0.28;
      const fb = ctx.createGain(); fb.gain.value = 0.32;
      verb.connect(fb).connect(verb); verb.connect(out);
      const pluck = (t, f, len) => {
        [1, 2.01, 3.98].forEach((m, k) => {          // fondamentale + harmoniques métalliques
          const o = ctx.createOscillator(), e = ctx.createGain();
          o.type = k ? 'sine' : 'triangle';
          o.frequency.value = f * m;
          const peak = [0.5, 0.16, 0.06][k];
          e.gain.setValueAtTime(0.0001, t);
          e.gain.exponentialRampToValueAtTime(peak, t + 0.005);
          e.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(1.2, len * beat * 1.6));
          o.connect(e); e.connect(out); e.connect(verb);
          o.start(t); o.stop(t + len * beat * 2 + 1);
        });
      };
      let i = 0;
      const stop = scheduler(t => {
        const [n, len] = song[i % song.length];
        pluck(t, N[n], len);
        i++;
        return t + len * beat + (i % song.length === 0 ? beat * 2 : 0);
      });
      return () => stop();
    },
  };

  // ---------- Lecture ----------
  function fadeTo(value, seconds) {
    const t = ctx.currentTime;
    master.gain.cancelScheduledValues(t);
    master.gain.setValueAtTime(master.gain.value, t);
    master.gain.linearRampToValueAtTime(value, t + seconds);
  }

  function play(type) {
    ensureContext();
    ctx.resume();
    if (current && current.type === type) return;
    const old = current;
    const bus = ctx.createGain(); bus.connect(master);
    const stopFn = makers[type](bus);
    current = { type, stop: stopFn, bus };
    // fondu enchaîné entre l'ancien et le nouveau son
    bus.gain.setValueAtTime(0, ctx.currentTime);
    bus.gain.linearRampToValueAtTime(1, ctx.currentTime + 1.2);
    if (old) {
      old.bus.gain.setValueAtTime(old.bus.gain.value, ctx.currentTime);
      old.bus.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.2);
      setTimeout(() => { old.stop(); old.bus.disconnect(); }, 1300);
    }
    fadeTo(volume, 1.5);
    startTimer();
    onChange?.({ playing: true, type });
  }

  function stop(fadeSeconds = 1.2) {
    if (!current) return;
    const c = current; current = null;
    fadeTo(0, fadeSeconds);
    setTimeout(() => { c.stop(); c.bus.disconnect(); }, fadeSeconds * 1000 + 100);
    clearInterval(timerId); endsAt = 0;
    onChange?.({ playing: false, type: c.type, remaining: timerMinutes * 60 });
  }

  function setVolume(v) {
    volume = v;
    if (ctx && current) fadeTo(v, 0.15);
  }

  // ---------- Minuteur d'arrêt avec fondu de 20 s ----------
  function startTimer() {
    clearInterval(timerId);
    endsAt = Date.now() + timerMinutes * 60000;
    tick();
    timerId = setInterval(tick, 1000);
  }
  function tick() {
    const left = Math.max(0, Math.round((endsAt - Date.now()) / 1000));
    onChange?.({ playing: !!current, type: current?.type, remaining: left });
    if (left === 0) stop(20);
  }
  function setTimer(min) {
    timerMinutes = min;
    if (current) startTimer();
    else onChange?.({ playing: false, remaining: min * 60 });
  }

  // ---------- Visualisation ----------
  const g = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let bins = new Uint8Array(128), rot = 0, energy = 0;
  function sizeCanvas() {
    const r = canvas.getBoundingClientRect();
    canvas.width = r.width * dpr; canvas.height = r.height * dpr;
  }
  sizeCanvas();
  window.addEventListener('resize', sizeCanvas);

  function draw() {
    const W = canvas.width, H = canvas.height, cx = W / 2, cy = H / 2;
    const R = Math.min(W, H) * 0.26;
    g.clearRect(0, 0, W, H);
    const playing = !!current && analyser;
    if (playing) analyser.getByteFrequencyData(bins);
    let sum = 0;
    rot += playing ? 0.004 : 0.0015;
    const n = 96;
    for (let i = 0; i < n; i++) {
      // on reflète le spectre pour un cercle symétrique
      const idx = i < n / 2 ? i : n - i;
      const v = playing ? bins[Math.floor(idx * 1.1) + 2] / 255 : (Math.sin(Date.now() / 900 + i * 0.25) + 1) * 0.06;
      sum += v;
      const a = (i / n) * Math.PI * 2 + rot;
      const len = R * 0.12 + v * R * 0.85;
      const x1 = cx + Math.cos(a) * (R + 6 * dpr), y1 = cy + Math.sin(a) * (R + 6 * dpr);
      const x2 = cx + Math.cos(a) * (R + 6 * dpr + len), y2 = cy + Math.sin(a) * (R + 6 * dpr + len);
      const t = i / n;
      g.strokeStyle = `hsla(${255 - t * 215 + Math.sin(rot * 3) * 10}, 95%, ${72 + v * 12}%, ${0.35 + v * 0.65})`;
      g.lineWidth = 3.2 * dpr; g.lineCap = 'round';
      g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    }
    energy += (sum / n - energy) * 0.1;
    // halo central qui respire avec l'énergie du son
    const halo = g.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * (1.25 + energy * 1.2));
    halo.addColorStop(0, 'rgba(255,226,168,0.22)');
    halo.addColorStop(1, 'rgba(183,166,255,0)');
    g.fillStyle = halo;
    g.beginPath(); g.arc(cx, cy, R * (1.25 + energy * 1.2), 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(183,166,255,0.35)'; g.lineWidth = 1 * dpr;
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);

  return {
    play, stop, setVolume, setTimer,
    get playing() { return !!current; },
    get type() { return current?.type; },
  };
}
